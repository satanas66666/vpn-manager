<?php

header("Content-Type: application/json");

// =========================
// INPUT
// =========================
$user = $_GET['user'] ?? '';

if (!$user) {
    echo json_encode(["status" => "error", "msg" => "No user"]);
    exit;
}

// Sanitizar
$user = escapeshellarg($user);

// =========================
// VALIDAR EXISTENCIA
// =========================
$exists = shell_exec("id -u $user 2>/dev/null");

if (!$exists) {
    echo json_encode([
        "status" => "invalid",
        "msg" => "Usuario no existe"
    ]);
    exit;
}

// =========================
// OBTENER EXPIRACIÓN SEGURA
// =========================
$raw = shell_exec("chage -l $user 2>/dev/null");

if (!$raw) {
    echo json_encode([
        "status" => "error",
        "msg" => "No se pudo leer chage"
    ]);
    exit;
}

$expire = "never";

foreach (explode("\n", $raw) as $line) {
    if (stripos($line, "Account expires") !== false) {
        $parts = explode(":", $line);
        $expire = trim($parts[1]);
        break;
    }
}

// =========================
// SIN EXPIRACIÓN
// =========================
if ($expire == "" || strtolower($expire) == "never") {

    echo json_encode([
        "status" => "ok",
        "expire" => "never",
        "expire_timestamp" => -1,
        "days_left" => -1,
        "msg" => "Cuenta sin expiración"
    ]);
    exit;
}

// =========================
// CONVERTIR FECHA
// =========================
$expTime = strtotime($expire);

// 🔥 VALIDACIÓN FUERTE
if ($expTime === false || $expTime < 1000000000) {
    echo json_encode([
        "status" => "error",
        "expire" => $expire,
        "msg" => "Fecha inválida en servidor"
    ]);
    exit;
}

$now = time();
$days = floor(($expTime - $now) / 86400);

// =========================
// RESPUESTA FINAL
// =========================
if ($now > $expTime) {

    echo json_encode([
        "status" => "expired",
        "expire" => date("Y-m-d", $expTime),
        "expire_timestamp" => $expTime,
        "days_left" => 0,
        "msg" => "Cuenta vencida"
    ]);

} else {

    echo json_encode([
        "status" => "ok",
        "expire" => date("Y-m-d", $expTime),
        "expire_timestamp" => $expTime,
        "days_left" => $days,
        "msg" => "Activo"
    ]);
}

