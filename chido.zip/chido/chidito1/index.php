<?php

header("Content-Type: text/plain");

// =========================
// RECIBIR JSON
// =========================
$input = json_decode(file_get_contents("php://input"), true);
$user = $input['user'] ?? '';

if (!$user) {
    echo "Not exist";
    exit;
}

// =========================
// VALIDAR USUARIO
// =========================
$exists = shell_exec("id -u " . escapeshellarg($user) . " 2>/dev/null");

if (!$exists) {
    echo "Not exist";
    exit;
}

// =========================
// OBTENER EXPIRACIÓN
// =========================
$raw = shell_exec("chage -l " . escapeshellarg($user) . " 2>/dev/null");

$expire = "";

foreach (explode("\n", $raw) as $line) {
    if (stripos($line, "Account expires") !== false) {
        $parts = explode(":", $line);
        $expire = trim($parts[1]);
        break;
    }
}

// =========================
// SIN EXPIRACIÓN
// =========================
if ($expire == "" || strtolower($expire) == "never") {
    echo "user:$user|expire:never|days:-1";
    exit;
}

// =========================
// CONVERTIR FECHA
// =========================
$expTime = strtotime($expire);

// 🔥 FIX BUG FECHA
if ($expTime === false || $expTime < 1000000000) {
    echo "Not exist";
    exit;
}

// =========================
// CALCULAR DÍAS
// =========================
$now = time();
$days = floor(($expTime - $now) / 86400);

// =========================
// EXPIRADO
// =========================
if ($now >= $expTime) {
    echo "Not exist";
    exit;
}

// =========================
// FORMATO QUE TU APP NECESITA
// =========================
echo "user:$user|expire:" . date("d/m/Y", $expTime) . "|days:$days";

