<?php

header("Content-Type: text/plain");

// =========================
// RECIBIR JSON (COMPATIBLE CON TU APP)
// =========================
$input = json_decode(file_get_contents("php://input"), true);
$user = $input['user'] ?? '';

if (!$user) {
    echo "Not exist";
    exit;
}

// =========================
// VALIDAR USUARIO
// =========================
$exists = shell_exec("id -u " . escapeshellarg($user) . " 2>/dev/null");

if (!$exists) {
    echo "Not exist"; // 🔥 tu app detecta esto
    exit;
}

// =========================
// OBTENER FECHA EXPIRACIÓN
// =========================
$raw = shell_exec("chage -l " . escapeshellarg($user) . " 2>/dev/null");

$expire = "";

foreach (explode("\n", $raw) as $line) {
    if (stripos($line, "Account expires") !== false) {
        $parts = explode(":", $line);
        $expire = trim($parts[1]);
        break;
    }
}

// =========================
// SIN EXPIRACIÓN
// =========================
if ($expire == "" || strtolower($expire) == "never") {

    echo "user:$user|expire:never|days:-1";
    exit;
}

// =========================
// CONVERTIR FECHA SEGURO
// =========================
$expTime = strtotime($expire);

// 🔥 FIX FECHA BUG
if ($expTime === false || $expTime < 1000000000) {

    echo "Not exist"; // evita fechas corruptas en app
    exit;
}

// =========================
// CALCULAR DÍAS
// =========================
$now = time();
$days = floor(($expTime - $now) / 86400);

// =========================
// USUARIO EXPIRADO
// =========================
if ($now >= $expTime) {

    echo "Not exist"; // 🔥 fuerza desconexión inmediata
    exit;
}

// =========================
// OK (FORMATO COMPATIBLE)
// =========================
echo "user:$user|expire:" . date("Y-m-d", $expTime) . "|days:$days";

