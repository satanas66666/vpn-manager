<?php
session_start();

// =========================
// 🔐 CONFIG
// =========================
$USER = "admin";
$PASS = "admin123";

// =========================
// 🔁 AUTO LOGIN (COOKIE)
// =========================
if (!isset($_SESSION['login']) && isset($_COOKIE['remember'])) {

    if ($_COOKIE['remember'] === hash('sha256', $USER.$PASS)) {
        $_SESSION['login'] = true;
        header("Location: admin.php");
        exit;
    }
}

// =========================
// 🔁 SI YA ESTÁ LOGEADO
// =========================
if (isset($_SESSION['login']) && $_SESSION['login'] === true) {
    header("Location: panel.php");
    exit;
}

// =========================
// 🔐 LOGIN
// =========================
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $user = trim($_POST['user'] ?? '');
    $pass = trim($_POST['pass'] ?? '');
    $remember = isset($_POST['remember']);

    if ($user === $USER && $pass === $PASS) {

        $_SESSION['login'] = true;

        // 🔥 RECORDAR SESIÓN (7 días)
        if ($remember) {
            setcookie(
                "remember",
                hash('sha256', $USER.$PASS),
                time() + (86400 * 7),
                "/",
                "",
                false,
                true
            );
        }

        header("Location: panel.php");
        exit;

    } else {
        $error = "❌ Usuario o contraseña incorrectos";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login Panel</title>

<style>
body{
    margin:0;
    background: radial-gradient(circle at top,#0f172a,#020617);
    font-family:sans-serif;
    color:white;
    display:flex;
    align-items:center;
    justify-content:center;
    height:100vh;
}

/* CARD */
.login-box{
    background:linear-gradient(145deg,#0f172a,#111827);
    padding:30px;
    border-radius:15px;
    width:320px;
    box-shadow:0 20px 40px rgba(0,0,0,0.6);
    text-align:center;
    border:1px solid #1e293b;
    animation:fadeIn 0.5s ease;
}

@keyframes fadeIn{
    from{opacity:0; transform:translateY(20px);}
    to{opacity:1; transform:translateY(0);}
}

h2{margin-bottom:5px;}
.sub{color:#94a3b8;font-size:13px;margin-bottom:20px;}

/* INPUT */
.input-group{
    position:relative;
    margin-bottom:15px;
}

.input-group input{
    width:100%;
    padding:10px 35px;
    border-radius:8px;
    border:1px solid #1e293b;
    background:#020617;
    color:white;
    outline:none;
}

.input-group input:focus{
    border-color:#3b82f6;
}

.input-group span{
    position:absolute;
    left:10px;
    top:50%;
    transform:translateY(-50%);
    color:#94a3b8;
}

/* CHECK */
.remember{
    display:flex;
    align-items:center;
    font-size:13px;
    margin-bottom:15px;
    gap:5px;
}

/* BOTÓN */
button{
    width:100%;
    padding:10px;
    border:none;
    border-radius:8px;
    background:linear-gradient(135deg,#3b82f6,#2563eb);
    color:white;
    font-weight:bold;
    cursor:pointer;
    transition:0.2s;
}

button:hover{transform:scale(1.05);}
button:active{transform:scale(0.95);}

/* LOADING */
.loading{
    display:none;
    margin-top:10px;
    font-size:13px;
    color:#3b82f6;
}

/* ERROR */
.error{
    background:#ef4444;
    padding:8px;
    border-radius:8px;
    margin-bottom:10px;
    font-size:13px;
}
</style>

<script>
function showLoading(){
    document.getElementById("btn").style.display = "none";
    document.getElementById("loading").style.display = "block";
}
</script>

</head>

<body>

<div class="login-box">

    <h2>🔐 Panel VPN PRO</h2>
    <div class="sub">Inicia sesión para continuar</div>

    <?php if($error): ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST" onsubmit="showLoading()">

        <div class="input-group">
            <span>👤</span>
            <input type="text" name="user" placeholder="Usuario" required>
        </div>

        <div class="input-group">
            <span>🔒</span>
            <input type="password" name="pass" placeholder="Contraseña" required>
        </div>

        <!-- 🔥 RECORDAR -->
        <div class="remember">
            <input type="checkbox" name="remember">
            Recordarme
        </div>

        <button id="btn">🚀 Iniciar sesión</button>

        <div id="loading" class="loading">
            ⏳ Iniciando sesión...
        </div>

    </form>

</div>

</body>
</html>

