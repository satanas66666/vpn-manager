<?php
session_start();

session_unset();
session_destroy();

// 🔥 borrar cookie
setcookie("remember", "", time() - 3600, "/");

header("Location: login.php");
exit;

