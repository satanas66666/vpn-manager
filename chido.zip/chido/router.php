<?php

$uri = urldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

// =========================
// 🔥 API PRINCIPAL
// =========================
if ($uri === '/api.php') {
    require __DIR__ . '/api.php';
    return;
}

// =========================
// 🔥 CHECK USER
// =========================
if ($uri === '/checkUser' || $uri === '/checkUser/') {
    require __DIR__ . '/chidito1/index.php';
    return;
}

// =========================
// 🔥 ARCHIVOS DIRECTOS (IMPORTANTE)
// =========================
$file = __DIR__ . $uri;

if ($uri !== '/' && file_exists($file) && !is_dir($file)) {
    return false; // deja que PHP sirva el archivo
}

// =========================
// 🔥 RUTAS DEL PANEL
// =========================
switch ($uri) {

    case '/':
    case '/index.php':
        require __DIR__ . '/login.php'; // 👈 entrada principal
        break;

    case '/panel':
    case '/panel.php':
        require __DIR__ . '/panel.php';
        break;

    case '/login':
    case '/login.php':
        require __DIR__ . '/login.php';
        break;

    case '/logout':
    case '/logout.php':
        require __DIR__ . '/logout.php';
        break;

    default:
        http_response_code(404);
        echo "404 - Not Found";
        break;
}

