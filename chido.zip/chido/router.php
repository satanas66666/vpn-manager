<?php

$uri = urldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

// =========================
// 🔹 CHECK USER
// =========================
if ($uri === '/checkUser' || $uri === '/checkUser/') {
    require __DIR__ . '/chidito1/index.php';
    return;
}

// =========================
// 🔹 PANEL ADMIN
// =========================
if ($uri === '/admin' || $uri === '/admin/') {
    require __DIR__ . '/admin.php';
    return;
}

// =========================
// 🔹 ARCHIVOS ESTÁTICOS
// =========================
$file = __DIR__ . $uri;
if ($uri !== '/' && file_exists($file) && !is_dir($file)) {
    return false;
}

// =========================
// 🔹 DEFAULT (ONLINE USERS)
// =========================
require __DIR__ . '/index.php';

