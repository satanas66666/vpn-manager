<?php

$uri = urldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

// /checkUser → chidito1
if ($uri === '/checkUser' || $uri === '/checkUser/') {
    require __DIR__ . '/chidito1/index.php';
    return;
}

// archivos normales
$file = __DIR__ . $uri;
if ($uri !== '/' && file_exists($file)) {
    return false;
}

// default → index principal
require __DIR__ . '/index.php';

