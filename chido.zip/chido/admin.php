<?php

// PROTECCIÓN BÁSICA
$PASS = "admin123";

if (!isset($_GET['key']) || $_GET['key'] !== $PASS) {
    die("Acceso denegado");
}

// OBTENER USUARIOS
$users = explode("\n", trim(shell_exec("cut -d: -f1 /etc/passwd")));

function getExpire($user) {
    $out = shell_exec("chage -l $user 2>/dev/null | grep 'Account expires'");
    if (!$out) return "N/A";
    $f = explode(':', $out);
    return trim($f[1]);
}

// CREAR USUARIO
if (isset($_POST['newuser'])) {
    $u = $_POST['user'];
    $p = $_POST['pass'];
    $d = $_POST['days'];

    shell_exec("useradd -M -s /bin/false $u");
    shell_exec("echo '$u:$p' | chpasswd");
    shell_exec("chage -E $(date -d '+$d days' +%Y-%m-%d) $u");
}

// ELIMINAR
if (isset($_GET['del'])) {
    $u = $_GET['del'];
    shell_exec("userdel $u");
}

?>
<!DOCTYPE html>
<html>
<head>
<title>Panel Admin</title>
<style>
body{background:#0f172a;color:white;font-family:sans-serif}
table{width:100%}
td,th{padding:8px}
input{padding:5px}
button{padding:6px}
</style>
</head>
<body>

<h2>Panel VPN</h2>

<form method="post">
<input name="user" placeholder="usuario">
<input name="pass" placeholder="pass">
<input name="days" placeholder="dias">
<button name="newuser">Crear</button>
</form>

<h3>Usuarios</h3>
<table border="1">
<tr><th>User</th><th>Expira</th><th>Acción</th></tr>

<?php
foreach ($users as $u) {
    if (strlen($u) < 3) continue;
    echo "<tr>
    <td>$u</td>
    <td>".getExpire($u)."</td>
    <td><a href='?key=$PASS&del=$u'>Eliminar</a></td>
    </tr>";
}
?>

</table>

</body>
</html>
