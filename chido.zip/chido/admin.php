<?php

$PASS = "admin123";

if (!isset($_GET['key']) || $_GET['key'] !== $PASS) {
    die("Acceso denegado");
}

// =========================
// 🔹 FILTRAR SOLO USUARIOS REALES
// UID >= 1000
// =========================
$raw = explode("\n", trim(shell_exec("awk -F: '$3 >= 1000 {print $1}' /etc/passwd")));

$users = array_filter($raw);

// =========================
// 🔹 FUNCIONES
// =========================
function getExpire($user) {
    $out = shell_exec("chage -l $user | grep 'Account expires'");
    if (!$out) return "N/A";
    $f = explode(':', $out);
    return trim($f[1]);
}

function getDaysLeft($user) {
    $out = shell_exec("chage -l $user | grep 'Account expires'");
    if (!$out) return "-";

    $f = explode(':', $out);
    $date = trim($f[1]);

    if ($date == "never") return "∞";

    $exp = strtotime($date);
    $now = time();

    return floor(($exp - $now) / 86400);
}

// =========================
// 🔹 API AJAX
// =========================
if (isset($_POST['action'])) {

    $u = $_POST['user'] ?? '';

    if ($_POST['action'] == "create") {
        $p = $_POST['pass'];
        $d = intval($_POST['days']);

        shell_exec("useradd -M -s /bin/false $u");
        shell_exec("echo '$u:$p' | chpasswd");
        shell_exec("chage -E $(date -d '+$d days' +%Y-%m-%d) $u");
        echo "OK";
        exit;
    }

    if ($_POST['action'] == "delete") {
        shell_exec("userdel $u");
        echo "OK";
        exit;
    }

    if ($_POST['action'] == "edit") {
        $d = intval($_POST['days']);
        shell_exec("chage -E $(date -d '+$d days' +%Y-%m-%d) $u");
        echo "OK";
        exit;
    }
}

?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Panel PRO</title>

<style>
body{
    background:#0f172a;
    color:white;
    font-family:sans-serif;
    padding:15px;
}

h2{
    margin-bottom:15px;
}

.card{
    background:#1e293b;
    padding:15px;
    border-radius:10px;
    margin-bottom:15px;
}

input{
    padding:8px;
    border:none;
    border-radius:6px;
    margin:5px;
}

button{
    padding:8px 12px;
    border:none;
    border-radius:6px;
    cursor:pointer;
}

.btn-green{background:#22c55e;color:white;}
.btn-blue{background:#3b82f6;color:white;}
.btn-red{background:#ef4444;color:white;}

.user{
    display:flex;
    justify-content:space-between;
    background:#020617;
    padding:10px;
    border-radius:8px;
    margin-bottom:8px;
    align-items:center;
}

small{color:#94a3b8;}
</style>

<script>
function send(action, user, pass='', days='') {

    let data = new FormData();
    data.append("action", action);
    data.append("user", user);
    data.append("pass", pass);
    data.append("days", days);

    fetch("?key=<?php echo $PASS ?>", {
        method: "POST",
        body: data
    })
    .then(r => r.text())
    .then(() => location.reload());
}

function createUser(){
    let u = document.getElementById("u").value;
    let p = document.getElementById("p").value;
    let d = document.getElementById("d").value;
    send("create", u, p, d);
}

function editUser(u){
    let d = prompt("Dias (+ / reemplazo):");
    if (d !== null) send("edit", u, '', d);
}

function delUser(u){
    if (confirm("Eliminar usuario?")) {
        send("delete", u);
    }
}
</script>

</head>
<body>

<h2>🚀 Panel VPN PRO</h2>

<div class="card">
<input id="u" placeholder="usuario">
<input id="p" placeholder="password">
<input id="d" placeholder="dias">
<button class="btn-green" onclick="createUser()">Crear</button>
</div>

<div class="card">
<?php foreach ($users as $u): ?>
<div class="user">
<div>
<b><?php echo $u ?></b><br>
<small>Expira: <?php echo getExpire($u) ?> | Días: <?php echo getDaysLeft($u) ?></small>
</div>

<div>
<button class="btn-blue" onclick="editUser('<?php echo $u ?>')">Editar</button>
<button class="btn-red" onclick="delUser('<?php echo $u ?>')">Eliminar</button>
</div>

</div>
<?php endforeach; ?>
</div>

</body>
</html>

