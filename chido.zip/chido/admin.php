<?php

$PASS = "admin123";

if (!isset($_GET['key']) || $_GET['key'] !== $PASS) {
    die("Acceso denegado");
}

// SOLO USUARIOS REALES (NO SISTEMA)
$users = explode("\n", trim(shell_exec("awk -F: '$3 >= 1000 {print $1}' /etc/passwd")));

function getExpire($user) {
    $out = shell_exec("chage -l $user | grep 'Account expires'");
    if (!$out) return "N/A";
    $f = explode(':', $out);
    return trim($f[1]);
}

// CREAR
if (isset($_POST['newuser'])) {
    $u = $_POST['user'];
    $p = $_POST['pass'];
    $d = intval($_POST['days']);

    shell_exec("useradd -M -s /bin/false $u");
    shell_exec("echo '$u:$p' | chpasswd");
    shell_exec("chage -E $(date -d '+$d days' +%Y-%m-%d) $u");
    exit;
}

// ELIMINAR
if (isset($_GET['del'])) {
    $u = $_GET['del'];
    shell_exec("userdel $u");
    exit;
}

// EDITAR
if (isset($_POST['edituser'])) {
    $u = $_POST['user'];
    $d = intval($_POST['days']);

    shell_exec("chage -E $(date -d '+$d days' +%Y-%m-%d) $u");
    exit;
}

?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
body{
    background:#0f172a;
    color:white;
    font-family:sans-serif;
    padding:10px;
}

table{width:100%;border-collapse:collapse;}
td,th{padding:10px;border:1px solid #1e293b;}

input{padding:6px;border-radius:6px;border:none;margin:5px;}
button{padding:6px 10px;border:none;border-radius:6px;cursor:pointer;}

.btn-create{background:#22c55e;color:white;}
.btn-delete{background:#ef4444;color:white;}
.btn-edit{background:#3b82f6;color:white;}
</style>

<script>
function reload(){setTimeout(()=>location.reload(),500);}

function createUser(){
    let f=new FormData();
    f.append("newuser",1);
    f.append("user",user.value);
    f.append("pass",pass.value);
    f.append("days",days.value);

    fetch("?key=<?php echo $PASS ?>",{method:"POST",body:f})
    .then(()=>reload());
}

function delUser(u){
    if(confirm("Eliminar?")){
        fetch("?key=<?php echo $PASS ?>&del="+u)
        .then(()=>reload());
    }
}

function editUser(u){
    let d=prompt("Dias nuevos:");
    if(d!=null){
        let f=new FormData();
        f.append("edituser",1);
        f.append("user",u);
        f.append("days",d);

        fetch("?key=<?php echo $PASS ?>",{method:"POST",body:f})
        .then(()=>reload());
    }
}
</script>

</head>
<body>

<h2>Panel VPN</h2>

<input id="user" placeholder="usuario">
<input id="pass" placeholder="pass">
<input id="days" placeholder="dias">
<button class="btn-create" onclick="createUser()">Crear</button>

<br><br>

<table>
<tr>
<th>User</th>
<th>Expira</th>
<th>Acción</th>
</tr>

<?php
foreach ($users as $u) {
    if (strlen($u) < 3) continue;

    echo "<tr>
    <td>$u</td>
    <td>".getExpire($u)."</td>
    <td>
    <button class='btn-edit' onclick=\"editUser('$u')\">Editar</button>
    <button class='btn-delete' onclick=\"delUser('$u')\">Eliminar</button>
    </td>
    </tr>";
}
?>

</table>

</body>
</html>

