<?php
session_start();

// =========================
// CONFIG
// =========================
$PASS = "admin123";

// =========================
// LOGIN SIMPLE
// =========================
if (!isset($_SESSION['login'])) {
    if (isset($_GET['key']) && $_GET['key'] === $PASS) {
        $_SESSION['login'] = true;
    } else {
        die("Acceso denegado");
    }
}

// =========================
// FUNCIONES
// =========================
function getExpire($user) {
    $out = shell_exec("chage -l $user 2>/dev/null | grep 'Account expires'");
    if (!$out) return "N/A";
    $f = explode(':', $out);
    return trim($f[1]);
}

// =========================
// CAMBIAR PUERTO CHECKUSER
// =========================
if (isset($_POST['change_port'])) {

    $new_port = intval($_POST['port']);

    if ($new_port > 0 && $new_port < 65535) {

        $service = "/etc/systemd/system/chido-check.service";

        if (file_exists($service)) {

            $content = file_get_contents($service);

            $content = preg_replace(
                '/php -S 0.0.0.0:\d+/',
                "php -S 0.0.0.0:$new_port",
                $content
            );

            file_put_contents($service, $content);

            shell_exec("systemctl daemon-reload");
            shell_exec("systemctl restart chido-check");

            $msg = "✅ Puerto cambiado a $new_port";

        } else {
            $msg = "❌ Servicio no encontrado";
        }

    } else {
        $msg = "❌ Puerto inválido";
    }
}

// =========================
// CREAR USUARIO
// =========================
if (isset($_POST['newuser'])) {
    $u = escapeshellarg($_POST['user']);
    $p = escapeshellarg($_POST['pass']);
    $d = intval($_POST['days']);

    shell_exec("useradd -M -s /bin/false $u");
    shell_exec("echo $u:$p | chpasswd");
    shell_exec("chage -E $(date -d '+$d days' +%Y-%m-%d) $u");

    header("Location: ".$_SERVER['REQUEST_URI']);
    exit;
}

// =========================
// ELIMINAR
// =========================
if (isset($_GET['del'])) {
    $u = escapeshellarg($_GET['del']);
    shell_exec("userdel $u");
    header("Location: ".$_SERVER['PHP_SELF']."?key=$PASS");
    exit;
}

// =========================
// EDITAR USUARIO
// =========================
if (isset($_POST['edituser'])) {
    $user = escapeshellarg($_POST['edit_name']);

    if (!empty($_POST['add_days'])) {
        $d = intval($_POST['add_days']);
        shell_exec("chage -E $(date -d '+$d days' +%Y-%m-%d) $user");
    }

    if (!empty($_POST['set_date'])) {
        $date = escapeshellarg($_POST['set_date']);
        shell_exec("chage -E $date $user");
    }

    header("Location: ".$_SERVER['REQUEST_URI']);
    exit;
}

// =========================
// OBTENER USUARIOS
// =========================
$users = explode("\n", trim(shell_exec("awk -F: '$3>=1000 {print $1}' /etc/passwd")));

// =========================
// OBTENER PUERTO ACTUAL
// =========================
$current_port = "N/A";
$service = "/etc/systemd/system/chido-check.service";

if (file_exists($service)) {
    $content = file_get_contents($service);
    if (preg_match('/:(\d+)/', $content, $match)) {
        $current_port = $match[1];
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Panel PRO</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
body{
    background:#0f172a;
    color:white;
    font-family:sans-serif;
}
h2{margin-bottom:10px}

input{
    padding:8px;
    border:none;
    border-radius:5px;
}

button{
    padding:8px 12px;
    border:none;
    border-radius:5px;
    cursor:pointer;
}

/* BOTONES */
.btn-create{background:#22c55e;color:white;}
.btn-del{background:#ef4444;color:white;}
.btn-edit{background:#3b82f6;color:white;}

/* TABLA */
table{
    width:100%;
    border-collapse:collapse;
}
th,td{
    padding:10px;
    border-bottom:1px solid #1e293b;
}
tr:hover{
    background:#1e293b;
}

/* MODAL */
.modal{
    display:none;
    position:fixed;
    top:0;left:0;
    width:100%;height:100%;
    background:rgba(0,0,0,0.6);
}
.modal-content{
    background:#1e293b;
    padding:20px;
    margin:10% auto;
    width:300px;
    border-radius:10px;
}
</style>

<script>
function openEdit(user){
    document.getElementById("editUser").value = user;
    document.getElementById("modal").style.display="block";
}
function closeModal(){
    document.getElementById("modal").style.display="none";
}

// 🔍 BUSCADOR
function buscarUsuario() {
    let filtro = document.getElementById("buscador").value.toLowerCase();
    let filas = document.querySelectorAll("table tr");

    filas.forEach((fila, index) => {
        if (index === 0) return;

        let texto = fila.innerText.toLowerCase();

        if (texto.includes(filtro)) {
            fila.style.display = "";
        } else {
            fila.style.display = "none";
        }
    });
}
</script>

</head>
<body>

<h2>🔥 Panel VPN PRO</h2>

<form method="post">
<input name="user" placeholder="usuario" required>
<input name="pass" placeholder="pass" required>
<input name="days" placeholder="dias" required>
<button class="btn-create" name="newuser">Crear</button>
</form>

<br>

<!-- 🔧 CAMBIO DE PUERTO -->
<p>Puerto actual CheckUser: <b><?= $current_port ?></b></p>

<form method="post">
<input type="number" name="port" placeholder="Nuevo puerto" required>
<button class="btn-create" name="change_port">Cambiar Puerto</button>
</form>

<?php if(isset($msg)) echo "<p>$msg</p>"; ?>

<br>

<!-- 🔍 BUSCADOR -->
<input type="text" id="buscador" onkeyup="buscarUsuario()" 
placeholder="🔍 Buscar usuario..." 
style="width:100%;margin-bottom:10px;">

<table>
<tr>
<th>User</th>
<th>Expira</th>
<th>Acción</th>
</tr>

<?php
foreach ($users as $u) {
    if (strlen($u) < 3) continue;

    echo "<tr>
    <td>$u</td>
    <td>".getExpire($u)."</td>
    <td>
        <button class='btn-edit' onclick=\"openEdit('$u')\">Editar</button>
        <a href='?key=$PASS&del=$u'>
            <button class='btn-del'>Eliminar</button>
        </a>
    </td>
    </tr>";
}
?>

</table>

<!-- MODAL EDIT -->
<div id="modal" class="modal">
<div class="modal-content">

<h3>Editar usuario</h3>

<form method="post">
<input type="hidden" name="edit_name" id="editUser">

<label>Agregar días:</label><br>
<input name="add_days" placeholder="ej: 5"><br><br>

<label>Fecha exacta:</label><br>
<input type="date" name="set_date"><br><br>

<button class="btn-edit" name="edituser">Guardar</button>
<button type="button" onclick="closeModal()">Cerrar</button>
</form>

</div>
</div>

</body>
</html>

